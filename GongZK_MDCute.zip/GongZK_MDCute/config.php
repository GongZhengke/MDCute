<?php
return array(
	'name'=>'GongZK_MDCute',
	'version'=>'1.0',
	'minsystemver'=>'0.2.0.0'
);
?>